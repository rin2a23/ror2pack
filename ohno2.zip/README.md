Thanks for downloading my pack theres nothing really to say other than enjoy and you're awesomesauce :3
Make sure to update the mods as updates arrive for them.
Use r2modman to configure your mods as needed especially balanced faster interactables.